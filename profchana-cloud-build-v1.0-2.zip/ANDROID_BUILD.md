# PROFCHANA Android v1.0

Este pacote contém um wrapper Android instalável que embute o MVP web do Profchana em um WebView.

## Gerar APK
Requer Android Studio/SDK e JDK 17.
Na pasta `android`:
- `./gradlew assembleDebug`

APK esperado:
`android/app/build/outputs/apk/debug/app-debug.apk`

Para produção: configurar assinatura release, ícone, splash nativa, URL da API, HTTPS, Play Integrity e testes em aparelhos.
