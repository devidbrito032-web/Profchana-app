import { Body, Controller, Get, Post, Req, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';

@Controller('sync')
export class SyncController {
  constructor(private prisma: PrismaService, private jwt: JwtService) {}
  private userId(req: any) {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!token) throw new UnauthorizedException('Token ausente');
    try { return this.jwt.verify(token).sub; } catch { throw new UnauthorizedException('Token inválido'); }
  }

  @Post('push')
  async push(@Req() req: any, @Body() body: any) {
    const userId = this.userId(req);
    const answers = Array.isArray(body.history) ? body.history : [];
    for (const item of answers) {
      const q = await this.prisma.question.findFirst({ where: { statement: item.statement } });
      if (!q) continue;
        const alternatives = await this.prisma.alternative.findMany({ where: { questionId: q.id }, orderBy: { id: 'asc' } });
      const selectedId = alternatives[Number.isInteger(item.selectedIndex) ? item.selectedIndex : 0]?.id || '';
      if (!selectedId) continue;
      const exists = await this.prisma.answer.findFirst({ where: { userId, questionId: q.id, answeredAt: new Date(item.date || Date.now()) } });
      if (!exists) await this.prisma.answer.create({ data: { userId, questionId: q.id, selectedId, isCorrect: !!item.ok, answeredAt: new Date(item.date || Date.now()) } });
    }
    return { ok: true, syncedAnswers: answers.length, state: { name: body.name, objective: body.objective, xp: body.xp || 0, streak: body.streak || 0, today: body.today || 0 } };
  }

  @Get('pull')
  async pull(@Req() req: any) {
    const userId = this.userId(req);
    const answers = await this.prisma.answer.findMany({ where: { userId }, include: { question: true }, orderBy: { answeredAt: 'asc' } });
    const correct = answers.filter(a => a.isCorrect).length;
    return { ok: true, state: { questionsAnswered: answers.length, correct, wrong: answers.length - correct, history: answers.map(a => ({ statement: a.question.statement, ok: a.isCorrect, date: a.answeredAt.getTime() })) } };
  }
}
