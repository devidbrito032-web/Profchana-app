import { Injectable, UnauthorizedException, ConflictException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { PrismaService } from '../prisma/prisma.service';
import { RegisterDto, LoginDto } from './auth.dto';

@Injectable()
export class AuthService {
  constructor(private jwt:JwtService, private prisma:PrismaService){}
  async register(dto:RegisterDto){
    const email=dto.email.toLowerCase();
    const exists=await this.prisma.user.findUnique({where:{email}});
    if(exists) throw new ConflictException('E-mail já cadastrado');
    const passwordHash=await bcrypt.hash(dto.password,12);
    const user=await this.prisma.user.create({data:{name:dto.name,email,passwordHash,goal:dto.goal,exam:dto.exam,dailyMinutes:dto.dailyMinutes}});
    return this.issue(user);
  }
  async login(dto:LoginDto){
    const user=await this.prisma.user.findUnique({where:{email:dto.email.toLowerCase()}});
    if(!user || !(await bcrypt.compare(dto.password,user.passwordHash))) throw new UnauthorizedException('E-mail ou senha inválidos');
    return this.issue(user);
  }
  private issue(user:any){return {accessToken:this.jwt.sign({sub:user.id,email:user.email,name:user.name}),user:{id:user.id,name:user.name,email:user.email,goal:user.goal,exam:user.exam,dailyMinutes:user.dailyMinutes}};}
}
