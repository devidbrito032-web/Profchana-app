import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
const prisma=new PrismaClient();
async function main(){
  const questions=[
    {subject:'matematica',topic:'Porcentagem',statement:'Quanto é 20% de 250?',difficulty:'facil',explanation:'20% = 20/100. Então 250 × 0,20 = 50.',alts:['25','40','50','60','75'],correct:2},
    {subject:'matematica',topic:'Regra de três',statement:'Se 3 cadernos custam R$ 18, quanto custam 5?',difficulty:'facil',explanation:'Cada caderno custa 18 ÷ 3 = 6. Cinco custam 5 × 6 = 30.',alts:['24','30','32','36','40'],correct:1},
    {subject:'portugues',topic:'Interpretação de texto',statement:'Na leitura de um texto, a ideia principal corresponde:',difficulty:'facil',explanation:'É a informação central que organiza as demais ideias.',alts:['ao detalhe menos importante','à informação central','apenas ao título','a uma opinião aleatória','à última frase'],correct:1}
  ];
  for(const q of questions){const old=await prisma.question.findFirst({where:{statement:q.statement}}); if(!old){await prisma.question.create({data:{subject:q.subject,topic:q.topic,statement:q.statement,difficulty:q.difficulty,explanation:q.explanation,alternatives:{create:q.alts.map((text,i)=>({text,isCorrect:i===q.correct}))}}});}}
  const email='demo@profchana.app'; const exists=await prisma.user.findUnique({where:{email}}); if(!exists){await prisma.user.create({data:{name:'Aluno Demo',email,passwordHash:await bcrypt.hash('123456',12),goal:'Concurso',exam:'PMSP — Soldado',dailyMinutes:60}});}
}
main().finally(()=>prisma.$disconnect());
