import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthController } from './auth/auth.controller';
import { AuthService } from './auth/auth.service';
import { PrismaModule } from './prisma/prisma.module';
import { SyncController } from './sync/sync.controller';
import { AiController } from './ai.controller';
import { AiService } from './ai.service';

@Module({ imports:[PrismaModule,JwtModule.register({secret:process.env.JWT_SECRET||'dev-secret-change-me',signOptions:{expiresIn:'7d'}})],controllers:[AuthController,SyncController,AiController],providers:[AuthService,AiService] })
export class AppModule {}
