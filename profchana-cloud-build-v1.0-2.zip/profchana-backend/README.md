# Profchana Backend v0.5

Backend NestJS + Prisma + PostgreSQL. Nesta versão o PostgreSQL deixa de ser apenas um schema e passa a ser usado pelo serviço de autenticação.

## Rodar localmente
1. `docker compose up -d`
2. `cd profchana-backend`
3. `npm install`
4. copie `.env.example` para `.env`
5. `npx prisma generate`
6. `npx prisma migrate dev --name init`
7. `npm run prisma:seed`
8. `npm run start:dev`

API: `POST /auth/register` e `POST /auth/login`.

Conta demo após seed: `demo@profchana.app` / `123456`.
