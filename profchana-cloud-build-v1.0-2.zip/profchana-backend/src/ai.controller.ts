import { Body, Controller, Post, Req, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { AiService, ExplainInput } from './ai.service';

@Controller('ai')
export class AiController {
  constructor(private ai: AiService, private jwt: JwtService) {}
  private auth(req: any) {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!token) throw new UnauthorizedException('Token ausente');
    try { return this.jwt.verify(token).sub; } catch { throw new UnauthorizedException('Token inválido'); }
  }

  @Post('explain')
  async explain(@Req() req: any, @Body() body: ExplainInput) {
    this.auth(req);
    if (!body?.question || !Array.isArray(body.alternatives)) throw new UnauthorizedException('Dados da questão inválidos');
    return this.ai.explain(body);
  }
}
