import { IsEmail, IsOptional, IsString, MinLength } from 'class-validator';
export class RegisterDto { @IsString() @MinLength(2) name!:string; @IsEmail() email!:string; @IsString() @MinLength(6) password!:string; @IsOptional() @IsString() goal?:string; @IsOptional() @IsString() exam?:string; @IsOptional() dailyMinutes?:number; }
export class LoginDto { @IsEmail() email!:string; @IsString() @MinLength(6) password!:string; }
