plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.profchana.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.profchana.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 100
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
