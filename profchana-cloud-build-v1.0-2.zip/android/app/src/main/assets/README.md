# PROFCHANA v1.0 — MVP integrado

Primeira versão integrada do aplicativo de estudos.

## Fluxo principal
- Autenticação e perfil
- Questões e correção
- Caderno de erros
- Motor pedagógico adaptativo
- Plano diário automático
- Simulados e estatísticas
- Camada Profchana IA
- Estrutura de sincronização

## Observação
Esta distribuição é um MVP/PWA. Para produção, configure o backend, PostgreSQL, provedor de IA, domínio/HTTPS e gere o APK Android com Flutter/Capacitor conforme a estratégia escolhida.
