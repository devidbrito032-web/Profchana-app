# PROFCHANA — Cloud Build

Projeto Android de teste preparado para compilação na nuvem via Codemagic.

## Estrutura
- `android/` — projeto Android WebView do PROFCHANA
- `profchana-app/` — PWA original
- `profchana-backend/` — scaffold do backend
- `codemagic.yaml` — workflow que gera o APK debug

## APK
O workflow executa `:app:assembleDebug` e publica o arquivo em:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Observação
Este é um APK de teste. Backend/IA remotos continuam dependendo de configuração própria; o app local funciona com os recursos embarcados.
