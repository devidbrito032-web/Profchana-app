# PROFCHANA v1.0

MVP integrado do aplicativo de estudos Profchana.

Inclui app web/PWA, backend e infraestrutura local.
