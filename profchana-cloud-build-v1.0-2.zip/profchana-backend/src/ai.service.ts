import { Injectable, ServiceUnavailableException } from '@nestjs/common';

export type ExplainInput = {
  question: string;
  alternatives: string[];
  correctIndex: number;
  selectedIndex: number;
  subject?: string;
  topic?: string;
  studentLevel?: string;
};

@Injectable()
export class AiService {
  async explain(input: ExplainInput) {
    const apiUrl = process.env.AI_API_URL;
    const apiKey = process.env.AI_API_KEY;
    const model = process.env.AI_MODEL || 'default';

    const fallback = this.fallback(input);
    if (!apiUrl || !apiKey) return { ...fallback, provider: 'fallback' };

    const prompt = `Você é o Profchana, um professor paciente para estudantes brasileiros. Explique em português simples, sem entregar apenas a resposta. Diagnostique o possível erro e ensine passo a passo.\n\nMatéria: ${input.subject || 'geral'}\nAssunto: ${input.topic || 'geral'}\nNível: ${input.studentLevel || 'iniciante'}\nQuestão: ${input.question}\nAlternativas: ${input.alternatives.map((a,i)=>`${String.fromCharCode(65+i)}) ${a}`).join(' | ')}\nAluno marcou: ${input.alternatives[input.selectedIndex]}\nCorreta: ${input.alternatives[input.correctIndex]}\n\nResponda com: diagnóstico, explicação passo a passo, macete e uma pergunta curta para verificar se o aluno entendeu.`;

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
        body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], temperature: 0.2 })
      });
      if (!response.ok) throw new Error(`AI provider HTTP ${response.status}`);
      const data: any = await response.json();
      const text = data?.choices?.[0]?.message?.content || data?.output?.[0]?.content?.[0]?.text;
      if (!text) throw new Error('Resposta de IA vazia');
      return { ...fallback, explanation: text, provider: 'remote' };
    } catch {
      return { ...fallback, provider: 'fallback', providerUnavailable: true };
    }
  }

  private fallback(input: ExplainInput) {
    const chosen = input.alternatives[input.selectedIndex] || '';
    const correct = input.alternatives[input.correctIndex] || '';
    return {
      diagnosis: `Você marcou “${chosen}”, mas a alternativa correta é “${correct}”. Vamos reconstruir o raciocínio antes de tentar novamente.`,
      explanation: 'Leia o enunciado com calma, identifique exatamente o que ele pede e depois escolha a operação ou regra que transforma os dados em resposta. O objetivo é entender o caminho, não decorar a alternativa.',
      tip: 'Macete do Profchana: primeiro descubra o que a questão pede; só depois faça a conta.',
      check: 'Consegue explicar com suas próprias palavras qual é o primeiro passo para resolver essa questão?'
    };
  }
}
